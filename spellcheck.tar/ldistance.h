unsigned int distance(const char *a , const  char *b);
