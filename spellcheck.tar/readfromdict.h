void read_dict();
void compare();
void display(int x , int y);

